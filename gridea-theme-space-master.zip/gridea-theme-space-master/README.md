# Gridea Theme 「 Space 」

> 基于静态博客生成器[Gridea](https://gridea.dev/)的卡片式、简洁风博客网站主题「Space」

### 安装方法
- 克隆项目到本地
- 复制「 space 」目录到「 Gridea 」主题文件中
- 重启「 Gridea 」客户端
- 在主题中选择「 space 」主题，点击保存
- 预览查看效果

### 待更新项
- 文章显示优化
- ~~社交分享（主要布局没写完）~~
- ~~暂时不支持评论功能（也是主要布局没写完）~~
- ~~主题自定义配置功能~~
- ~~主页文章列表如果不设置封面，排版优化~~
- 页面搜索功能完善

### 示例

[示例网站](https://zhangajian.com)

<img src="https://blog-img-hosting.oss-cn-shanghai.aliyuncs.com/blog/theme_info/zaj_blog_01-min.png" alt="首页" style="display:block;max-width:100%;">
